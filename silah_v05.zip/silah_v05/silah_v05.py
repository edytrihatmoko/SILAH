# -*- coding: utf-8 -*-
"""
/***************************************************************************
 silah_v05
                                 A QGIS plugin
                              -------------------
        begin                : 2024-09-07
        git sha              : $Format:%H$
        email                : ditjen.infrastruktur@atrbpn.go.id
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox, QFileDialog
from qgis.core import QgsVectorLayer, QgsProject
import os.path
import geopandas as gpd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.patches as mpatches
from .silah_v05_dialog import silah_v05Dialog

class silah_v05:
    """Core plugin logic for silah_v05."""

    def __init__(self, iface):
        """Constructor for plugin class."""
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = self.tr(u'&silah_v05')
        self.first_start = None
        self.dlg = None

    def tr(self, message):
        """Translate messages."""
        return QCoreApplication.translate('silah_v05', message)

    def add_action(self, icon_path, text, callback, enabled_flag=True, parent=None):
        """Add action for toolbar/menu."""
        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        self.iface.addToolBarIcon(action)
        self.iface.addPluginToMenu(self.menu, action)
        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        icon_path = ':/plugins/silah_v05/icon.png'
        self.add_action(
            icon_path,
            text=self.tr(u'silah_v05'),
            callback=self.run,
            parent=self.iface.mainWindow()
        )
        self.first_start = True

    def unload(self):
        """Remove the plugin menu item and icon from QGIS GUI."""
        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&silah_v05'), action)
            self.iface.removeToolBarIcon(action)

    def run(self):
        """Run the main dialog for the plugin."""
        if self.first_start:
            self.first_start = False
            self.dlg = silah_v05Dialog()  # Initialize the dialog

        self.dlg.show()
        result = self.dlg.exec_()

        if result:
            # Get the input/output/report file paths from the dialog
            input_file = self.dlg.lineEdit_input.text()
            output_file = self.dlg.lineEdit_output.text()
            report_file = self.dlg.lineEdit_outputReport.text()

            # Validate paths before proceeding
            if not self.validate_paths(input_file, output_file, report_file):
                return

            try:
                # Run the data processing and save the results
                self.process_data(input_file, output_file, report_file)
                QMessageBox.information(self.dlg, "Success", f"Analysis complete. Output saved: {output_file}")
                
                # Load the output layer into QGIS
                self.load_output_layer(output_file)

            except Exception as e:
                QMessageBox.critical(self.dlg, "Error", f"An error occurred: {str(e)}")

    def validate_paths(self, input_file, output_file, report_file):
        """Validate the provided file paths."""
        if not input_file or not os.path.isfile(input_file):
            QMessageBox.warning(self.dlg, "Error", "Input file is invalid.")
            return False
        if not output_file or not os.path.isdir(os.path.dirname(output_file)):
            QMessageBox.warning(self.dlg, "Error", "Output file location is invalid.")
            return False
        if not report_file or not os.path.isdir(report_file):
            QMessageBox.warning(self.dlg, "Error", "Report directory is invalid.")
            return False
        return True

    def process_data(self, input_file, output_file, report_file):
        """Main logic for processing the input shapefile."""
        try:
            # Load GeoDataFrame
            gdf = gpd.read_file(input_file)
            original_gdf = gpd.read_file(input_file)

            # Mapping to equivalent columns from silah_v045 results
            columns_to_plot = {
                'classifica': 'Manual',  # Equivalent to 'classification_result'
                'natural_je': 'Natural Jenks',  # Equivalent to 'natural_jenks_result'
                'percent_33': 'Persentase 33%',  # Equivalent to 'percent_33_result'
                'quantile_r': 'Quantile',  # Equivalent to 'quantile_result'
                'equal_inte': 'Equal Interval'  # Equivalent to 'equal_interval_result'
            }

            # Check if required columns are present in the input file
            missing_columns = [col for col in columns_to_plot if col not in gdf.columns]
            if missing_columns:
                QMessageBox.warning(self.dlg, "Error", f"The following required columns are missing in the input file: {', '.join(missing_columns)}")
                return

            result_gdf = gdf.copy()

            # Perform classification and prediction mapping for each target column
            for column, title in columns_to_plot.items():
                result_gdf = self.classify_and_predict(result_gdf, column, title, original_gdf)

            # Save the updated GeoDataFrame to a new shapefile
            result_gdf.to_file(output_file)
            print(f"Shapefile saved to {output_file}")

            # Generate the HTML report with bullet points
            self.generate_report(result_gdf, report_file, input_file)

        except Exception as e:
            raise RuntimeError(f"An error occurred during processing: {str(e)}")

    def classify_and_predict(self, gdf, target_column, strtitle, original_gdf):
        """Perform classification and generate maps."""
        features = ['slope_cate', 'lulc', 'road_categ', 'neighbor_c', 'forest_are']
        target = target_column

        # Drop rows with NaN values in the required feature columns
        gdf = gdf.dropna(subset=features + [target_column])

        if gdf.empty:
            raise ValueError("No valid data to process after removing rows with NaN values.")

        X = gdf[features]
        y = gdf[target]

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)
        
        # Train model
        model = DecisionTreeClassifier(random_state=42)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        # Evaluate and display results
        accuracy = accuracy_score(y_test, y_pred)
        print(f"Accuracy for {strtitle}: {accuracy}")
        classification_rep1 = classification_report(y_test, y_pred)
        print(f"Classification Report for {strtitle}:\n", classification_rep1)

        filtered_predictions = model.predict(gdf[features])
        original_gdf[f'pr_{target_column}'] = 0
        original_gdf.loc[gdf.index, f'pr_{target_column}'] = filtered_predictions
        rekomendasi_mapping = {3: 'Rekomendasi Tinggi', 2: 'Rekomendasi Sedang', 1: 'Rekomendasi Rendah'}
        original_gdf[f'str_{target_column}'] = original_gdf[f'pr_{target_column}'].map(rekomendasi_mapping)

        # Plot maps for visual result
        self.plot_recommendation_map(original_gdf, target_column, strtitle)

        return gdf

    def generate_report(self, gdf, report_file, input_file):
        """Generate an HTML report with detailed values for each classification."""
        report_path = os.path.join(report_file, f'{os.path.basename(input_file).replace(".shp", "")}_report.html')
        
        with open(report_path, 'w') as f:
            f.write(f'<h1>Field Survey Priority Report for {os.path.basename(input_file)}</h1>')
            f.write('<h2>Classification Results:</h2>')
            
            # Iterate over the classification results to include details
            f.write('<h3>Details for Each Classification:</h3>')
            f.write('<ul>')
            f.write('<li><strong>Manual Classification (classifica):</strong></li>')
            f.write(f'<p>{gdf["classifica"].value_counts().to_dict()}</p>')
            f.write('<li><strong>Natural Jenks (natural_je):</strong></li>')
            f.write(f'<p>{gdf["natural_je"].value_counts().to_dict()}</p>')
            f.write('<li><strong>Persentase 33% (percent_33):</strong></li>')
            f.write(f'<p>{gdf["percent_33"].value_counts().to_dict()}</p>')
            f.write('<li><strong>Quantile (quantile_r):</strong></li>')
            f.write(f'<p>{gdf["quantile_r"].value_counts().to_dict()}</p>')
            f.write('<li><strong>Equal Interval (equal_inte):</strong></li>')
            f.write(f'<p>{gdf["equal_inte"].value_counts().to_dict()}</p>')
            f.write('</ul>')
            
            # Indicate that maps have been generated and saved
            f.write('<p>Each classification model has been applied and maps have been generated.</p>')
            f.write('<p>The results are saved as maps in PNG format, located in the same directory as this report.</p>')

        print(f"Report saved to: {report_path}")


    def plot_recommendation_map(self, gdf, target_column, strtitle):
        """Plot and save the recommendation map, and ensure the PNG file is saved with the report."""
        rekomendasi_mapping = {3: 'Rekomendasi Tinggi', 2: 'Rekomendasi Sedang', 1: 'Rekomendasi Rendah'}
        gdf[f'str_{target_column}'] = gdf[f'str_{target_column}'].fillna('No Recommendation')

        colors = {'Rekomendasi Tinggi': 'red', 'Rekomendasi Sedang': 'orange', 'Rekomendasi Rendah': 'yellow', 'No Recommendation': 'gray'}
        gdf['color'] = gdf[f'str_{target_column}'].map(colors)

        fig, ax = plt.subplots(1, 1, figsize=(15, 10))
        gdf.plot(ax=ax, color=gdf['color'])

        legend_patches = [mpatches.Patch(color=color, label=label) for label, color in colors.items()]
        plt.legend(handles=legend_patches, loc='lower left')
        plt.title(f'Rekomendasi Mapping by {strtitle}')

        # Save the map as a PNG file with a name that matches the input file
        png_path = os.path.join(os.path.dirname(self.dlg.lineEdit_outputReport.text()), f"{strtitle}_map_{os.path.basename(self.dlg.lineEdit_input.text()).replace('.shp', '')}.png")
        plt.savefig(png_path)  # Save the map
        plt.show()

        print(f"PNG saved to {png_path}")

    def load_output_layer(self, output_file):
        """Load the output shapefile as a new layer in QGIS."""
        # Get the base name of the shapefile (without the .shp extension)
        layer_name = os.path.basename(output_file).replace('.shp', '')
        
        # Load the output shapefile into QGIS
        layer = QgsVectorLayer(output_file, layer_name, "ogr")
        
        if not layer.isValid():
            QMessageBox.warning(self.dlg, "Error", f"Could not load the layer: {layer_name}")
        else:
            self.remove_existing_layer(layer_name)  # Remove existing layer with the same name if exists
            QgsProject.instance().addMapLayer(layer)

    def remove_existing_layer(self, layer_name):
        """Remove any existing layer in QGIS with the given name."""
        layers = QgsProject.instance().mapLayersByName(layer_name)
        if layers:
            for layer in layers:
                QgsProject.instance().removeMapLayer(layer)
